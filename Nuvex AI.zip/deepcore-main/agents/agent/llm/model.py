from abc import ABC


class Model(ABC):
    """Base class for all models."""

    def get_model(self):
        pass
