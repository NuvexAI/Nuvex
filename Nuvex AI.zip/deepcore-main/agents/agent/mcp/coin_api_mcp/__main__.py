from coin_api_mcp import main

main()