from enum import Enum

class VipLevel(Enum):
    """VIP Level Enum"""
    NORMAL = 0  # Normal user
    VIP = 1     # VIP user 